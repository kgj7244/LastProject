package com.ch.ch.model;

public class MovieTheater {
	private int mt_num; //상영관번호
	private String mt_name; //상영관이름
	private int mt_count; //좌석
	private int t_num; //극장번호
}
