package com.ch.ch.service;

import java.util.List;

import com.ch.ch.model.Movie;

public interface TicketService {

	List<Movie> select();

}
