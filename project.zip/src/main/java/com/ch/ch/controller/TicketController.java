package com.ch.ch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.ch.model.Movie;
import com.ch.ch.model.MovieTheater;
import com.ch.ch.model.Screen;
import com.ch.ch.model.Theater;
import com.ch.ch.service.MovieService;
import com.ch.ch.service.ScreenService;
import com.ch.ch.service.TheaterService;
import com.ch.ch.service.TicketService;

@Controller
public class TicketController {
	@Autowired
	private TicketService ts; // 예매
	@Autowired
	private MovieService ms; // 영화
	@Autowired
	private TheaterService tts; // 극장
	@Autowired
	private ScreenService ss; // 상영
	@RequestMapping("ticketMainForm")
	public String ticketMainForm(Model model, Theater theater) {
		List<Movie> movie = ms.list(); // 영화 리스트
		List<Theater> theater1 = tts.locList(theater); // 극장 지역 리스트
		model.addAttribute("movie", movie);
		model.addAttribute("theater1", theater1);
		return "ticket/ticketMainForm";
	}
	@RequestMapping(value = "selectTheater") // 극장주소을 클릭시 옆에 극장명 나오기
	public String selectTheater(String id, Model model) {
		List<Theater> selectTheater = tts.selectTheater(id);
		model.addAttribute("selectTheater", selectTheater);
		return "ticket/selectTheater";
	}
	@RequestMapping(value = "selectTime") 
	public String selectTime(String m_title, String t_title, String sc_date, Model model) {
		Movie movie = ms.selectTitle(m_title); // movie.getM_num() 영화 번호 가져옴
		int movie_num = movie.getM_num();
		Theater theater = tts.selectTitle(t_title); // theater.getT_num() 극장번호 가져옴
		int theater_num = theater.getT_num();
		List<Screen> screen = ss.selectTitleList(movie_num, theater_num, sc_date);
		 //int movieTheaterCnt = ss.selectCnt(theater.getT_num());
		 //System.out.println("movieTheaterCnt : " + movieTheaterCnt);
		 
		model.addAttribute("movie",movie);
		model.addAttribute("theater",theater);
		model.addAttribute("screen",screen);
		return "ticket/selectTime";
	}
}