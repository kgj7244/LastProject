package com.ch.ch.dao;

import java.util.List;

import com.ch.ch.model.Movie;

public interface TicketDao {

	List<Movie> select();

}
